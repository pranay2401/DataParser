import org.codehaus.jackson.JsonFactory;
import org.codehaus.jackson.JsonNode;
import org.codehaus.jackson.JsonParser;
import org.codehaus.jackson.map.ObjectMapper;

import java.io.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

public class DataParser {

    //Constants
    private static final String CSV = "csv";
    private static final String JSON = "json";
    private static final String FAVOURITE_FOOD = "favourite_food";
    private static final String BIRTH_TIMESTAMP = "birth_timestamp";
    private static final String BIRTH_TIMEZONE = "birth_timezone";
    private static final String SIBLINGS = "siblings";
    private static final String FIRST_NAME = "first_name";
    private static final String LAST_NAME = "last_name";

    public static void main(String[] args) throws IOException {
        List<Map> data = null;
        if (args.length != 0) {
            if (args[0].endsWith(CSV)) {
                data = getDataCSV(args[0]);
            } else if (args[0].endsWith(JSON)) {
                data = getDataListJson(args[0]);
            }
            if (data != null && !data.isEmpty()) {
                printAvgSiblings(data);
                printPopularFoods(data);
                printBirthsPerMonth(data);
            }
        } else {
            System.out.println("No supported data file given");
        }
    }

    private static void printPopularFoods(List<Map> data) {
        if (data != null && !data.isEmpty()) {
            Map<Object, Integer> foods = new HashMap<>();
            data.forEach(item ->
            {
                // Add if absent and increment if present
                String key = item.get(FAVOURITE_FOOD).toString().toLowerCase().trim();
                if (foods.get(key) != null) {
                    foods.put(key, Integer.parseInt(foods.get(key).toString()) + 1);
                } else {
                    foods.put(key, 1);
                }
            });
            System.out.println("Favourite foods:");
            printTopNFoods(foods, 3);
        }
    }

    private static void printTopNFoods(Map<Object, Integer> foods, int n) {
        if (foods.size() <= n) {
            prettyPrint(foods);
            return;
        }
        for (int loop = 0; loop < n; loop++) {
            printAndRemoveMaxEntry(foods);
        }
    }

    private static void printAndRemoveMaxEntry(Map<Object, Integer> foods) {
        Optional<Map.Entry<Object, Integer>> entry = foods.entrySet().stream().max(Comparator.comparing(Map.Entry::getValue));
        if (entry.isPresent()) {
            String key = entry.get().getKey().toString();
            if (key.length() <= 7) {
                System.out.println(key + "\t\t" + entry.get().getValue());
            } else {
                System.out.println(key + "\t" + entry.get().getValue());
            }
            foods.remove(entry.get().getKey());
        }
    }

    private static Map<Object, Integer> getBirthsMap() {
        Map<Object, Integer> births = new LinkedHashMap<>();
        births.put("January", 0);
        births.put("February", 0);
        births.put("March", 0);
        births.put("April", 0);
        births.put("May", 0);
        births.put("June", 0);
        births.put("July", 0);
        births.put("August", 0);
        births.put("Septemer", 0);
        births.put("October", 0);
        births.put("November", 0);
        births.put("December", 0);
        return births;
    }

    private static Map<Integer, String> getMonthsMap() {
        Map<Integer, String> months = new HashMap();
        months.put(0, "January");
        months.put(1, "February");
        months.put(2, "March");
        months.put(3, "April");
        months.put(4, "May");
        months.put(5, "June");
        months.put(6, "July");
        months.put(7, "August");
        months.put(8, "Septemer");
        months.put(9, "October");
        months.put(10, "November");
        months.put(11, "December");
        return months;
    }

    private static void printBirthsPerMonth(List<Map> data) {
        System.out.println("Births per month:");
        if (data != null && !data.isEmpty()) {
            Map<Integer, String> months = getMonthsMap();
            Map<Object, Integer> births = getBirthsMap();
            data.forEach(item -> {
                long timestamp = Long.parseLong(item.get(BIRTH_TIMESTAMP).toString());
                String timezone = item.get(BIRTH_TIMEZONE).toString();
                String[] zone = timezone.split(":");
                int hours = Integer.parseInt(zone[0]);
                int mins = Integer.parseInt(zone[1]);
                timestamp += hours * 60 * 60 * 1000 + mins * 60 * 1000;
                Date d = new Date(timestamp);
                if (births.get(months.get(d.getMonth())) == null) {
                    births.put(months.get(d.getMonth()), 1);
                } else {
                    births.put(months.get(d.getMonth()), Integer.parseInt(births.get(months.get(d.getMonth())).toString()) + 1);
                }
            });
            prettyPrint(births);
        }
    }

    private static void prettyPrint(Map<Object, Integer> map) {
        map.forEach((key, value) -> {
            if (key.toString().length() <= 7) {
                System.out.println(key + "\t\t" + value);
            } else {
                System.out.println(key + "\t" + value);
            }
        });
    }

    private static void printAvgSiblings(List<Map> data) {
        double result = 0;
        if (data != null && !data.isEmpty()) {
            AtomicInteger sum = new AtomicInteger(0);
            data.forEach(item -> {
                int x = Integer.parseInt(item.get(SIBLINGS).toString());
                sum.set(sum.get() + x);
            });
            result = Math.ceil(sum.get() / (double) data.size());
        }
        System.out.println("Average Siblings: " + (int) result);
    }

    /**
     * Method to get .csv file data in a map in the form of key value pairs
     *
     * @param pathToFile path of the location of the file
     * @return List of map objects
     * @throws FileNotFoundException error if specified path has no file
     */
    private static List<Map> getDataCSV(String pathToFile) throws FileNotFoundException {
        String line = "";
        String cvsSplitBy = ",";
        List<Map> list = new ArrayList<>();
        int i = 0;
        Map<Integer, String> keyMap = new HashMap<>();
        try (BufferedReader br = new BufferedReader(new FileReader(pathToFile))) {
            while ((line = br.readLine()) != null) {
                // Leave the first line of .csv file
                if (i == 0) {
                    i++;
                    String[] keyValues = line.split(cvsSplitBy);
                    for (int len = 0; len < keyValues.length; len++) {
                        keyMap.put(len, keyValues[len]);
                    }
                    continue;
                }
                // use comma as separator
                String[] dataValues = line.split(cvsSplitBy);
                Map<String, String> data = new HashMap<>();
                for (int index = 0; index < dataValues.length; index++) {
                    data.put(keyMap.get(index), dataValues[index]);
                }
                list.add(data);
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
        return list;
    }

    /**
     * Method to get data from json file in the form of Map
     *
     * @param pathToFile path to the location of file
     * @return list of map objects
     * @throws IOException error case if file is not found
     */
    private static List<Map> getDataListJson(String pathToFile) throws IOException {
        JsonFactory jsonFactory = new JsonFactory();
        JsonParser jp = jsonFactory.createJsonParser(new File(pathToFile));
        jp.setCodec(new ObjectMapper());
        JsonNode jsonNode = jp.readValueAsTree();
        List<Map> list = new ArrayList<>();
        jsonNode.forEach(item -> {
            Map<String, String> map = new HashMap<>();
            item.getFields().forEachRemaining(entry -> {
                map.put(entry.getKey(), entry.getValue().toString().replace("\"", ""));
            });
            list.add(map);
        });
        return list;
    }
}