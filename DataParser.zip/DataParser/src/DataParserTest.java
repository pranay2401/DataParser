import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintStream;

public class DataParserTest {

    private static final String TEST_OUTPUT_CSV = "Average Siblings: 3\r\n" +
            "Favourite foods:\r\n" +
            "meatballs\t3328\r\n" +
            "pizza\t\t3245\r\n" +
            "ice cream\t2881\r\n" +
            "Births per month:\r\n" +
            "January\t\t42140\r\n" +
            "February\t153\r\n" +
            "March\t\t537\r\n" +
            "April\t\t700\r\n" +
            "May\t\t547\r\n" +
            "June\t\t682\r\n" +
            "July\t\t599\r\n" +
            "August\t\t450\r\n" +
            "Septemer\t1668\r\n" +
            "October\t\t55\r\n" +
            "November\t1333\r\n" +
            "December\t1136\r\n";

    private static final String TEST_OUTPUT_JSON = "Average Siblings: 3\r\n" +
            "Favourite foods:\r\n" +
            "pizza\t\t3350\r\n" +
            "meatballs\t3331\r\n" +
            "ice cream\t2905\r\n" +
            "Births per month:\r\n" +
            "January\t\t42088\r\n" +
            "February\t139\r\n" +
            "March\t\t602\r\n" +
            "April\t\t672\r\n" +
            "May\t\t594\r\n" +
            "June\t\t700\r\n" +
            "July\t\t573\r\n" +
            "August\t\t475\r\n" +
            "Septemer\t1614\r\n" +
            "October\t\t71\r\n" +
            "November\t1355\r\n" +
            "December\t1117\r\n";

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    @Test
    public void testMainSuccessCsv() {
        try {
            final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
            System.setOut(new PrintStream(outContent));
            DataParser.main(new String[]{"population.csv"});
            Assert.assertEquals(TEST_OUTPUT_CSV, outContent.toString());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void testMainSuccessJson() {
        try {
            final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
            System.setOut(new PrintStream(outContent));
            DataParser.main(new String[]{"population.json"});
            Assert.assertEquals(TEST_OUTPUT_JSON, outContent.toString());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Test(expected = FileNotFoundException.class)
    public void testMainFileNotFound() throws IOException {
            final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
            System.setOut(new PrintStream(outContent));
            DataParser.main(new String[]{"data\\data.json"});
    }
}